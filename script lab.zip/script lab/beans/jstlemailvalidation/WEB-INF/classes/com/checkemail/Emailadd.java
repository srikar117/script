package com.checkemail;
import java.util.regex.*;

public class Emailadd {

    public boolean emailval(String email) {
        if (email != null) {
            // Regex pattern to match any general email format
            Pattern p = Pattern.compile("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
            Matcher m = p.matcher(email);
            return m.matches();
        } else {
            return false;
        }
    }
}
