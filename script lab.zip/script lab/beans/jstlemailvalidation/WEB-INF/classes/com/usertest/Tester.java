package com.usertest;
 public class Tester
 {
 public boolean valid(String username)
 {
 if(username==null || username.length()==0)
 {
 return false;
 }
 if(username.length()<5 || username.length()>10)
{
 return false;
 }
 return true;
 }
 }